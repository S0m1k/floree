/* concept-atelier.jsx — Concept B: Atelier Quiet (air, asymmetric grid, reveal masks) */

const { useState: useStateB, useEffect: useEffectB, useRef: useRefB } = React;

function ConceptAtelier() {
  const rootRef = useRefB(null);
  const [slide, setSlide] = useStateB(0);
  const [cartOpen, setCartOpen] = useStateB(false);
  const [cart, setCart] = useStateB([]);

  const slides = [
    { img: FLOWER_IMAGES.hero2, name: "Matin",  ru: "утро" },
    { img: FLOWER_IMAGES.hero3, name: "Verger", ru: "сад"  },
    { img: FLOWER_IMAGES.hero1, name: "Rosée",  ru: "роса" },
    { img: FLOWER_IMAGES.hero4, name: "Soir",   ru: "вечер" },
  ];

  useEffectB(() => {
    const id = setInterval(() => setSlide((s) => (s + 1) % slides.length), 6000);
    return () => clearInterval(id);
  }, []);

  const addToCart = (p) => { setCart((c) => [...c, p]); setCartOpen(true); };

  return (
    <div ref={rootRef} className="at-root">
      <CustomCursor scope={rootRef} />
      <Header onCart={() => setCartOpen(true)} cartCount={cart.length} />

      {/* HERO — split with massive serif left, slider card right */}
      <section className="at-hero">
        <div className="at-hero__copy">
          <div className="eyebrow">— SS·26</div>
          <h1 className="serif at-hero__title">
            Цветы,<br/>
            <em>которые</em><br/>
            помнят <em>про&nbsp;тебя</em>.
          </h1>
          <p className="at-hero__lede">
            Floree — небольшая мастерская в&nbsp;Петербурге.
            Каждый букет&nbsp;— ручная сборка из&nbsp;того,
            что пришло сегодня утром.
          </p>
          <div className="at-hero__actions">
            <button className="btn btn--filled" data-hover>
              Заказать букет
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M1 7H13M13 7L8 2M13 7L8 12" stroke="currentColor"/></svg>
            </button>
            <a href="#about" className="at-hero__lk" data-hover>о&nbsp;студии</a>
          </div>
        </div>

        <div className="at-hero__media">
          <div className="at-hero__slider">
            {slides.map((s, i) => (
              <div key={i} className={`at-hero__slide ${i === slide ? "is-active" : ""}`}>
                <img src={s.img} alt={s.name} />
              </div>
            ))}
            <div className="at-hero__cap">
              <div className="mono">{String(slide + 1).padStart(2, "0")} / {String(slides.length).padStart(2, "0")}</div>
              <div className="serif at-hero__cap-name">{slides[slide].name}<span> — {slides[slide].ru}</span></div>
            </div>
          </div>

          <div className="at-hero__nav">
            {slides.map((_, i) => (
              <button
                key={i}
                className={`at-hero__nav-dot ${i === slide ? "is-active" : ""}`}
                onClick={() => setSlide(i)}
                data-hover
              />
            ))}
          </div>
        </div>

        <div className="at-hero__sidetext mono">
          ↓ scroll<br/>прокрути
        </div>
      </section>

      {/* INTRO LINE */}
      <section className="at-line">
        <Reveal kind="up">
          <div className="at-line__row">
            <span className="eyebrow">— Каждое утро в&nbsp;9:00</span>
            <span className="at-line__bar" />
            <span className="serif at-line__msg">
              Свежий завоз. <em>Без&nbsp;холодильника.</em>
            </span>
          </div>
        </Reveal>
      </section>

      {/* ASYMMETRIC GRID — featured 6 with reveal masks */}
      <section className="at-grid" id="catalog">
        <div className="at-grid__head">
          <Reveal kind="up">
            <div className="eyebrow">— Каталог</div>
            <h2 className="serif at-grid__title">
              <em>Девять</em> букетов сезона
            </h2>
          </Reveal>
        </div>

        <div className="at-grid__layout">
          {/* row 1 */}
          <div className="at-grid__cell at-grid__cell--lg">
            <ProductCardAtelier product={PRODUCTS[0]} onAdd={() => addToCart(PRODUCTS[0])} />
          </div>
          <div className="at-grid__cell at-grid__cell--sm at-grid__cell--offset">
            <ProductCardAtelier product={PRODUCTS[1]} onAdd={() => addToCart(PRODUCTS[1])} />
          </div>
          {/* row 2 */}
          <div className="at-grid__cell at-grid__cell--sm">
            <ProductCardAtelier product={PRODUCTS[2]} onAdd={() => addToCart(PRODUCTS[2])} />
          </div>
          <div className="at-grid__cell at-grid__cell--lg at-grid__cell--right">
            <ProductCardAtelier product={PRODUCTS[3]} onAdd={() => addToCart(PRODUCTS[3])} />
          </div>
          {/* row 3 */}
          <div className="at-grid__cell at-grid__cell--md">
            <ProductCardAtelier product={PRODUCTS[4]} onAdd={() => addToCart(PRODUCTS[4])} />
          </div>
          <div className="at-grid__cell at-grid__cell--md at-grid__cell--offset-sm">
            <ProductCardAtelier product={PRODUCTS[5]} onAdd={() => addToCart(PRODUCTS[5])} />
          </div>
        </div>

        <Reveal kind="up" className="at-grid__more">
          <a href="#" className="btn" data-hover>
            Все 24 букета
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M1 7H13M13 7L8 2M13 7L8 12" stroke="currentColor"/></svg>
          </a>
        </Reveal>
      </section>

      {/* PROCESS — number list */}
      <section className="at-process">
        <Reveal kind="up">
          <div className="eyebrow" style={{ marginBottom: 32 }}>— Как мы работаем</div>
        </Reveal>
        <div className="at-process__grid">
          {[
            { n: "01", t: "Слушаем",  p: "Расскажите, кому и&nbsp;по&nbsp;какому поводу — мы&nbsp;поймём, что нужно." },
            { n: "02", t: "Выбираем", p: "Едем на&nbsp;утренний завоз и&nbsp;берём то, что в&nbsp;этот день — лучшее." },
            { n: "03", t: "Собираем", p: "Каждый букет — ручная сборка одного флориста, без&nbsp;конвейера." },
            { n: "04", t: "Везём",    p: "Курьер с&nbsp;пометкой «бережно», доставка по&nbsp;СПб за&nbsp;1.5–2 часа." },
          ].map((s, i) => (
            <Reveal key={s.n} kind="up" delay={i * 100} className="at-step">
              <div className="mono at-step__n">{s.n}</div>
              <h4 className="serif at-step__t">{s.t}</h4>
              <p className="at-step__p" dangerouslySetInnerHTML={{ __html: s.p }} />
            </Reveal>
          ))}
        </div>
      </section>

      {/* BIG IMAGE STRIP — full bleed reveal */}
      <section className="at-strip">
        <MaskImage src={FLOWER_IMAGES.studio} alt="Студия Floree" aspect="21/9" />
        <div className="at-strip__overlay">
          <Reveal kind="up">
            <div className="serif at-strip__msg">
              <em>Studio — </em>Полтавский&nbsp;2
            </div>
          </Reveal>
        </div>
      </section>

      {/* WEDDING / SUBSCRIPTION teaser */}
      <section className="at-services">
        <Reveal kind="up" className="at-service">
          <div className="at-service__media">
            <MaskImage src={FLOWER_IMAGES.wedding} alt="Свадьба" aspect="4/3" />
          </div>
          <div className="at-service__copy">
            <div className="eyebrow">— Свадебная флористика</div>
            <h3 className="serif at-service__t">
              Букет невесты,<br/>арка, оформление зала
            </h3>
            <p>Работаем с&nbsp;парой за&nbsp;3–6 месяцев до&nbsp;даты. Проводим встречу, делаем мудборд, считаем смету.</p>
            <a href="#" className="at-service__lk" data-hover>Узнать о&nbsp;свадебной услуге →</a>
          </div>
        </Reveal>
        <Reveal kind="up" delay={150} className="at-service at-service--rev">
          <div className="at-service__media">
            <MaskImage src={FLOWER_IMAGES.vase} alt="Подписка" aspect="4/3" />
          </div>
          <div className="at-service__copy">
            <div className="eyebrow">— Подписка на цветы</div>
            <h3 className="serif at-service__t">
              Свежие букеты домой<br/>раз&nbsp;в&nbsp;неделю
            </h3>
            <p>Выберите ритм — каждую неделю или раз в&nbsp;две. Меняем букет, не&nbsp;меняем привычку.</p>
            <a href="#" className="at-service__lk" data-hover>Оформить подписку →</a>
          </div>
        </Reveal>
      </section>

      {/* QUOTE band */}
      <section className="at-band">
        <Ticker items={["floree.ru", "ручная сборка", "Полтавский 2", "доставка по СПб", "ежедневно 9—21"]} speed={55} />
      </section>

      {/* CTA */}
      <section className="at-cta">
        <Reveal kind="fade">
          <h3 className="serif at-cta__t">
            Хотите букет<br/>
            <em>не&nbsp;как у&nbsp;всех?</em>
          </h3>
          <p className="at-cta__p">
            Напишите флористу — обсудим повод, цвет и&nbsp;настроение.
            Соберём что-то ваше.
          </p>
          <button className="btn btn--filled at-cta__btn" data-hover>
            Написать флористу
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M1 7H13M13 7L8 2M13 7L8 12" stroke="currentColor"/></svg>
          </button>
        </Reveal>
      </section>

      <Footer />

      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} items={cart} setItems={setCart} />
    </div>
  );
}

function ProductCardAtelier({ product, onAdd }) {
  return (
    <article className="at-card" data-hover>
      <div className="at-card__media">
        <MaskImage src={product.img} alt={product.name} aspect="3/4" />
        <button className="at-card__add" onClick={onAdd} data-hover aria-label="Добавить в корзину">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M9 2V16M2 9H16" stroke="currentColor"/></svg>
        </button>
      </div>
      <div className="at-card__meta">
        <div>
          <h4 className="serif at-card__t">{product.name}</h4>
          <div className="at-card__sub">{product.composition}</div>
        </div>
        <div className="at-card__price mono">{fmtPrice(product.price)}</div>
      </div>
    </article>
  );
}

Object.assign(window, { ConceptAtelier });
