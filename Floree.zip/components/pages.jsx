/* pages.jsx — Product detail, Cart/Checkout, About, Contacts, Shipping */

const { useState: useStateP, useRef: useRefP } = React;

/* ============ PRODUCT DETAIL PAGE ============ */
function PageProduct() {
  const ref = useRefP(null);
  const [pkg, setPkg]   = useStateP("paper");
  const [card, setCard] = useStateP(false);
  const product = PRODUCTS[2]; // Rosée
  const basePrice = 9800;
  const packs = [{ id: "paper", t: "крафт-бумага" }, { id: "linen", t: "лён" }, { id: "box", t: "коробка" }];
  const currentPrice = basePrice + (pkg === "box" ? 600 : 0) + (card ? 200 : 0);

  return (
    <div ref={ref} className="pg-root pg-product">
      <CustomCursor scope={ref} />
      <Header cartCount={1} />

      <div className="pg-crumbs">
        <a href="#" data-hover>Главная</a>
        <span>/</span>
        <a href="#" data-hover>Каталог</a>
        <span>/</span>
        <span className="pg-crumbs__current">Rosée</span>
      </div>

      <section className="pg-prod">
        <div className="pg-prod__media">
          <div className="pg-prod__main">
            <img src={product.img} alt={product.name} />
          </div>
          <div className="pg-prod__thumbs">
            {[FLOWER_IMAGES.blush, FLOWER_IMAGES.pink, FLOWER_IMAGES.peony, FLOWER_IMAGES.rose].map((src, i) => (
              <div key={i} className={`pg-prod__thumb ${i === 0 ? "is-active" : ""}`} data-hover>
                <img src={src} alt="" />
              </div>
            ))}
          </div>
        </div>

        <div className="pg-prod__info">
          <div className="eyebrow">— N° 003 / весна 2026</div>
          <h1 className="serif pg-prod__title">Rosée</h1>
          <div className="pg-prod__price mono">{fmtPrice(currentPrice)}</div>

          <p className="pg-prod__desc">
            Тонкий букет в&nbsp;утренней пастельной палитре — пионовидные розы, ранункулюсы и&nbsp;гортензия.
            Сборка одного флориста, ручная упаковка. Каждый букет немного отличается от&nbsp;предыдущего —
            это делает его живым.
          </p>

          <div className="pg-prod__field">
            <div className="eyebrow">Упаковка</div>
            <div className="pg-prod__opts">
              {packs.map(p => (
                <button
                  key={p.id}
                  className={`pg-opt pg-opt--sm ${pkg === p.id ? "is-active" : ""}`}
                  onClick={() => setPkg(p.id)}
                  data-hover
                >
                  {p.t}{p.id === "box" && <span className="mono"> +600</span>}
                </button>
              ))}
            </div>
          </div>

          <label className="pg-prod__check">
            <input type="checkbox" checked={card} onChange={(e) => setCard(e.target.checked)} />
            <span className="pg-prod__check-box" data-hover>{card && "✓"}</span>
            <span>Открытка с&nbsp;рукописным посланием</span>
            <span className="mono pg-prod__check-price">+200&nbsp;₽</span>
          </label>

          <div className="pg-prod__actions">
            <button className="btn btn--filled pg-prod__buy" data-hover>
              Добавить в&nbsp;корзину · {fmtPrice(currentPrice)}
            </button>
            <button className="pg-prod__fav" data-hover aria-label="В избранное">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M10 17S3 12.5 3 8C3 5.5 5 4 7 4C8.5 4 10 5 10 6.5C10 5 11.5 4 13 4C15 4 17 5.5 17 8C17 12.5 10 17 10 17Z" stroke="currentColor"/>
              </svg>
            </button>
          </div>

          <div className="pg-prod__details">
            <details open>
              <summary>
                <span className="serif">Состав букета</span>
                <span className="pg-prod__chev">+</span>
              </summary>
              <ul className="pg-prod__list">
                <li><span>Пионовидные розы David Austin</span><span className="mono">5 шт</span></li>
                <li><span>Ранункулюсы</span><span className="mono">7 шт</span></li>
                <li><span>Гортензия</span><span className="mono">2 шт</span></li>
                <li><span>Скабиоза</span><span className="mono">3 шт</span></li>
                <li><span>Эвкалипт</span><span className="mono">по сезону</span></li>
              </ul>
            </details>
            <details>
              <summary>
                <span className="serif">Доставка и оплата</span>
                <span className="pg-prod__chev">+</span>
              </summary>
              <p>Доставка по СПб за 1.5–2 часа. Курьер с пометкой «бережно». Оплата картой, СБП, наличными.</p>
            </details>
            <details>
              <summary>
                <span className="serif">Уход за букетом</span>
                <span className="pg-prod__chev">+</span>
              </summary>
              <p>Подрежьте стебли под углом. Меняйте воду каждый день. Не ставьте рядом с фруктами.</p>
            </details>
          </div>
        </div>
      </section>

      <section className="pg-related">
        <Reveal kind="up">
          <div className="eyebrow">— Похожие букеты</div>
          <h3 className="serif pg-related__t">Из&nbsp;<em>той&nbsp;же</em> палитры</h3>
        </Reveal>
        <div className="pg-related__grid">
          {PRODUCTS.slice(3, 7).map((p, i) => (
            <article key={p.id} className="ed-card" data-hover>
              <div className="ed-card__media">
                <img src={p.img} alt={p.name} />
              </div>
              <div className="ed-card__meta">
                <div className="ed-card__row">
                  <h4 className="serif ed-card__t">{p.name}</h4>
                  <span className="ed-card__price">{fmtPrice(p.price)}</span>
                </div>
                <div className="ed-card__sub">{p.composition}</div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <Footer />
    </div>
  );
}

/* ============ CART / CHECKOUT PAGE ============ */
function PageCheckout() {
  const ref = useRefP(null);
  const [step, setStep] = useStateP(2);
  const items = [PRODUCTS[2], PRODUCTS[5], PRODUCTS[1]];
  const subtotal = items.reduce((s, p) => s + p.price, 0);
  const delivery = 500;
  const total = subtotal + delivery;

  return (
    <div ref={ref} className="pg-root pg-checkout">
      <CustomCursor scope={ref} />
      <Header cartCount={items.length} />

      <div className="pg-checkout__progress mono">
        {["Корзина", "Доставка", "Оплата"].map((s, i) => (
          <div key={s} className={`pg-checkout__step ${step === i + 1 ? "is-active" : ""} ${step > i + 1 ? "is-done" : ""}`}>
            <span className="pg-checkout__step-num">0{i + 1}</span>
            <span className="pg-checkout__step-t">{s}</span>
          </div>
        ))}
      </div>

      <section className="pg-co">
        <div className="pg-co__main">
          <h1 className="serif pg-co__title">Оформление <em>заказа</em></h1>

          <div className="pg-co__block">
            <div className="pg-co__block-head">
              <span className="mono">— 01 / получатель</span>
            </div>
            <div className="pg-co__form">
              <label className="pg-input">
                <span>Имя получателя</span>
                <input type="text" defaultValue="Анна Соколова" />
              </label>
              <label className="pg-input">
                <span>Телефон</span>
                <input type="tel" defaultValue="+7 921 555 12 34" />
              </label>
              <label className="pg-input pg-input--full">
                <span>Известно ли получателю о доставке?</span>
                <div className="pg-radio-row">
                  <label><input type="radio" name="known" defaultChecked /><span>Да</span></label>
                  <label><input type="radio" name="known" /><span>Нет, сюрприз</span></label>
                </div>
              </label>
            </div>
          </div>

          <div className="pg-co__block">
            <div className="pg-co__block-head">
              <span className="mono">— 02 / адрес и время</span>
            </div>
            <div className="pg-co__form">
              <label className="pg-input pg-input--full">
                <span>Адрес доставки</span>
                <input type="text" defaultValue="ул. Большая Морская, 14, кв. 7" />
              </label>
              <label className="pg-input">
                <span>Дата</span>
                <input type="text" defaultValue="14 мая 2026" />
              </label>
              <label className="pg-input">
                <span>Время</span>
                <input type="text" defaultValue="14:00 — 16:00" />
              </label>
              <label className="pg-input pg-input--full">
                <span>Комментарий курьеру</span>
                <input type="text" placeholder="Например: позвонить за 10 минут" />
              </label>
            </div>
          </div>

          <div className="pg-co__block">
            <div className="pg-co__block-head">
              <span className="mono">— 03 / открытка</span>
            </div>
            <div className="pg-co__form">
              <label className="pg-input pg-input--full">
                <span>Текст открытки (рукописно)</span>
                <textarea rows="3" defaultValue="С днём весны, моя дорогая. Всегда твой, А."></textarea>
              </label>
            </div>
          </div>

          <div className="pg-co__actions">
            <a href="#" className="btn" data-hover>← Назад в корзину</a>
            <button className="btn btn--filled" data-hover>
              Перейти к&nbsp;оплате · {fmtPrice(total)}
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M1 7H13M13 7L8 2M13 7L8 12" stroke="currentColor"/></svg>
            </button>
          </div>
        </div>

        <aside className="pg-co__aside">
          <div className="pg-co__summary">
            <div className="eyebrow" style={{ marginBottom: 24 }}>— Заказ</div>
            <div className="pg-co__items">
              {items.map((p, i) => (
                <div key={i} className="pg-co__item">
                  <img src={p.img} alt={p.name} />
                  <div className="pg-co__item-meta">
                    <div className="serif">{p.name}</div>
                    <div className="pg-co__item-sub">{p.composition}</div>
                  </div>
                  <div className="mono">{fmtPrice(p.price)}</div>
                </div>
              ))}
            </div>
            <div className="pg-co__rows">
              <div><span>Подытог</span><span className="mono">{fmtPrice(subtotal)}</span></div>
              <div><span>Доставка по СПб</span><span className="mono">{fmtPrice(delivery)}</span></div>
            </div>
            <div className="pg-co__total">
              <span>Итого</span>
              <span className="serif">{fmtPrice(total)}</span>
            </div>
          </div>
        </aside>
      </section>

      <Footer />
    </div>
  );
}

/* ============ ABOUT PAGE ============ */
function PageAbout() {
  const ref = useRefP(null);
  return (
    <div ref={ref} className="pg-root pg-about">
      <CustomCursor scope={ref} />
      <Header />

      <section className="pg-about__hero">
        <div className="pg-about__hero-copy">
          <Reveal kind="up"><div className="eyebrow">— О студии</div></Reveal>
          <Reveal kind="up" delay={120}>
            <h1 className="serif pg-about__title">
              <em>Маленькая</em> цветочная студия<br/>
              в&nbsp;большом городе.
            </h1>
          </Reveal>
        </div>
        <Reveal kind="fade" delay={200} className="pg-about__hero-media">
          <MaskImage src={FLOWER_IMAGES.studio} alt="Студия Floree" aspect="3/4" />
        </Reveal>
      </section>

      <section className="pg-about__story">
        <Reveal kind="up">
          <div className="eyebrow">— История</div>
        </Reveal>
        <div className="pg-about__story-grid">
          <Reveal kind="up" delay={80}>
            <p className="serif pg-about__lede">
              Floree открылась в&nbsp;2018 году — небольшой комнатой в&nbsp;Полтавском проезде,
              двумя флористами и&nbsp;желанием делать букеты, которые хочется унести с&nbsp;собой.
            </p>
          </Reveal>
          <Reveal kind="up" delay={160}>
            <p>
              За&nbsp;восемь лет мы&nbsp;собрали более 12&nbsp;000 букетов, но&nbsp;не&nbsp;превратились в&nbsp;конвейер.
              Студия выросла до&nbsp;четырёх флористов — и&nbsp;это потолок: каждый букет должен оставаться
              авторским, а&nbsp;не&nbsp;шаблонным.
            </p>
            <p>
              Мы&nbsp;работаем только с&nbsp;живыми цветами, без&nbsp;стабилизированных, без&nbsp;консервированных
              композиций «навсегда». Цветок красив именно своей конечностью — и&nbsp;мы&nbsp;уважаем это.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="pg-about__numbers">
        {[
          { n: "2018", t: "год основания" },
          { n: "12 000+", t: "собранных букетов" },
          { n: "4", t: "флориста в&nbsp;команде" },
          { n: "1.5 ч", t: "средняя доставка по&nbsp;СПб" },
        ].map((s, i) => (
          <Reveal key={i} kind="up" delay={i * 80} className="pg-about__num">
            <div className="serif pg-about__num-val">{s.n}</div>
            <div className="eyebrow" dangerouslySetInnerHTML={{ __html: s.t }} />
          </Reveal>
        ))}
      </section>

      <section className="pg-about__map">
        <Reveal kind="up">
          <div className="eyebrow">— Как нас найти</div>
          <h2 className="serif pg-about__map-t">
            Полтавский проезд, <em>2</em>
          </h2>
          <p className="pg-about__map-p">
            Санкт-Петербург, м.&nbsp;Площадь Восстания &mdash; 4&nbsp;минуты пешком.
          </p>
        </Reveal>
        <Reveal kind="fade" delay={120}>
          <div className="pg-about__map-frame">
            <iframe
              src="https://yandex.ru/map-widget/v1/?ll=30.358515%2C59.931180&mode=search&oid=1102798495&ol=biz&z=17"
              title="Флористическая студия Floree на&nbsp;Яндекс&nbsp;Картах"
              width="100%"
              height="100%"
              frameBorder="0"
              loading="lazy"
              allowFullScreen
            ></iframe>
            <div className="pg-about__map-meta mono">
              <span>Данные Яндекс&nbsp;Карт</span>
              <a href="https://yandex.ru/maps/?ll=30.358515%2C59.931180&z=17" target="_blank" rel="noopener" data-hover>Открыть в&nbsp;Яндекс&nbsp;Картах &rarr;</a>
            </div>
          </div>
        </Reveal>
      </section>

      <section className="pg-about__team">
        <Reveal kind="up">
          <div className="eyebrow" style={{ textAlign: "center" }}>— Команда</div>
          <h2 className="serif pg-about__team-t">Четыре пары рук</h2>
        </Reveal>
        <div className="pg-about__team-grid">
          {[
            { name: "Анна",   role: "главный флорист, основатель", img: FLOWER_IMAGES.florist },
            { name: "Дарья",  role: "флорист, свадебная флористика", img: FLOWER_IMAGES.hand },
            { name: "Юля",    role: "флорист, ежедневные букеты",   img: FLOWER_IMAGES.studio },
            { name: "Михаил", role: "флорист, корпоративные заказы", img: FLOWER_IMAGES.vase },
          ].map((m, i) => (
            <Reveal key={m.name} kind="up" delay={i * 80} className="pg-about__person">
              <MaskImage src={m.img} alt={m.name} aspect="4/5" delay={i * 60} />
              <div className="pg-about__person-meta">
                <h4 className="serif pg-about__person-n">{m.name}</h4>
                <div className="pg-about__person-r">{m.role}</div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <Footer />
    </div>
  );
}

/* ============ CONTACTS PAGE ============ */
function PageContacts() {
  const ref = useRefP(null);
  return (
    <div ref={ref} className="pg-root pg-contacts">
      <CustomCursor scope={ref} />
      <Header />

      <section className="pg-cnt__hero">
        <Reveal kind="up"><div className="eyebrow">— Контакты</div></Reveal>
        <Reveal kind="up" delay={120}>
          <h1 className="serif pg-cnt__title">
            Зайдите. Или&nbsp;<em>напишите</em>.<br/>
            Или&nbsp;<em>позвоните</em>.
          </h1>
        </Reveal>
      </section>

      <section className="pg-cnt__grid">
        <Reveal kind="up" className="pg-cnt__col">
          <div className="eyebrow">— Студия</div>
          <h3 className="serif pg-cnt__col-t">Полтавский проезд, 2</h3>
          <p>Санкт-Петербург, м. Площадь Восстания, 4 минуты пешком.</p>
          <div className="pg-cnt__hours mono">
            <div><span>пн — пт</span><span>09:00 — 21:00</span></div>
            <div><span>сб — вс</span><span>10:00 — 20:00</span></div>
          </div>
        </Reveal>

        <Reveal kind="up" delay={120} className="pg-cnt__col">
          <div className="eyebrow">— Связаться</div>
          <h3 className="serif pg-cnt__col-t">+7&nbsp;993&nbsp;075&nbsp;05&nbsp;77</h3>
          <p>Звонки в&nbsp;часы работы. В&nbsp;остальное время — Telegram, WhatsApp.</p>
          <div className="pg-cnt__lks">
            <a href="#" className="btn" data-hover>Telegram</a>
            <a href="#" className="btn" data-hover>WhatsApp</a>
            <a href="#" className="btn" data-hover>Instagram</a>
          </div>
        </Reveal>

        <Reveal kind="up" delay={240} className="pg-cnt__col">
          <div className="eyebrow">— Сотрудничество</div>
          <h3 className="serif pg-cnt__col-t">corporate@floree.ru</h3>
          <p>Корпоративные заказы, оформление пространств, свадьбы.</p>
        </Reveal>
      </section>

      <section className="pg-cnt__map">
        <div className="pg-cnt__map-frame">
          <img src="https://images.unsplash.com/photo-1524813686514-a57563d77965?w=2000&q=80" alt="Карта" />
          <div className="pg-cnt__map-pin">
            <div className="pg-cnt__map-pin-dot"></div>
            <div className="pg-cnt__map-pin-card">
              <div className="serif">Floree</div>
              <div className="mono">Полтавский проезд, 2</div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

/* ============ SHIPPING PAGE ============ */
function PageShipping() {
  const ref = useRefP(null);
  return (
    <div ref={ref} className="pg-root pg-ship">
      <CustomCursor scope={ref} />
      <Header />

      <section className="pg-ship__hero">
        <Reveal kind="up"><div className="eyebrow">— Доставка и оплата</div></Reveal>
        <Reveal kind="up" delay={120}>
          <h1 className="serif pg-ship__title">
            Доставка<br/>и&nbsp;<em>оплата</em>.
          </h1>
        </Reveal>
      </section>

      <section className="pg-ship__intro">
        <Reveal kind="up">
          <p className="serif pg-ship__intro-lede">
            Мы&nbsp;доставляем заказы ежедневно <em>с&nbsp;9:00 до&nbsp;21:00</em>.
          </p>
        </Reveal>
        <Reveal kind="up" delay={120}>
          <p className="pg-ship__intro-p">
            Стоимость доставки рассчитывается индивидуально
            в&nbsp;зависимости от&nbsp;времени доставки и&nbsp;отдалённости конечной точки.
          </p>
        </Reveal>
        <Reveal kind="up" delay={200}>
          <p className="pg-ship__intro-p">
            Наши флористы с&nbsp;радостью сделают для&nbsp;вас предварительный рассчёт
            при&nbsp;согласовании букета.
          </p>
        </Reveal>
        <Reveal kind="up" delay={280}>
          <div className="pg-ship__note">
            <span className="mono">— важно</span>
            <p>
              Если получателя не&nbsp;оказалось на&nbsp;месте в&nbsp;указанный промежуток времени,
              повторный выезд курьера оплачивается дополнительно.
            </p>
          </div>
        </Reveal>
      </section>

      <section className="pg-ship__pay">
        <Reveal kind="up">
          <div className="eyebrow">— Оплата</div>
          <h3 className="serif pg-ship__pay-t">Напрямую на&nbsp;сайте или&nbsp;в&nbsp;магазине</h3>
        </Reveal>
        <Reveal kind="up" delay={120}>
          <p className="pg-ship__pay-lede">
            Оплата напрямую на&nbsp;сайте через&nbsp;удобные сервисы или&nbsp;в магазине при&nbsp;самовывозе.
          </p>
        </Reveal>
      </section>

      <section className="pg-ship__support">
        <Reveal kind="up">
          <div className="eyebrow">— Техническая поддержка</div>
          <h3 className="serif pg-ship__sup-t">
            С&nbsp;9:00 до&nbsp;21:00<br/>мы&nbsp;<em>на&nbsp;связи</em>.
          </h3>
        </Reveal>
        <Reveal kind="up" delay={120}>
          <p className="pg-ship__sup-p">
            Поможем определиться с&nbsp;выбором, обговорить детали заказа
            и&nbsp;решить любую проблему.
          </p>
          <div className="pg-ship__sup-lks">
            <a href="tel:+79930750577" className="btn btn--filled" data-hover>+7&nbsp;993&nbsp;075&nbsp;05&nbsp;77</a>
            <a href="#" className="btn" data-hover>Telegram</a>
            <a href="#" className="btn" data-hover>WhatsApp</a>
          </div>
        </Reveal>
      </section>

      <Footer />
    </div>
  );
}

/* ============ CATALOG PAGE ============ */
function PageCatalog() {
  const ref = useRefP(null);
  const [filter, setFilter] = useStateP("all");
  return (
    <div ref={ref} className="pg-root pg-catalog">
      <CustomCursor scope={ref} />
      <Header />

      <section className="pg-cat__hero">
        <Reveal kind="up"><div className="eyebrow">— Каталог · весна 2026</div></Reveal>
        <Reveal kind="up" delay={100}>
          <h1 className="serif pg-cat__title">
            <em>Двадцать четыре</em><br/>
            живых букета
          </h1>
        </Reveal>
        <Reveal kind="up" delay={200}>
          <p className="pg-cat__lede">
            Композиции этой недели. Состав может немного меняться&nbsp;— зависит от&nbsp;утреннего завоза.
          </p>
        </Reveal>
      </section>

      <div className="pg-cat__bar">
        <div className="pg-cat__filters">
          {[
            ["all", "Все"],
            ["under", "до 6 000 ₽"],
            ["mid", "6 — 10 000 ₽"],
            ["over", "от 10 000 ₽"],
            ["wedding", "Свадебные"],
            ["box", "В коробке"],
          ].map(([id, t]) => (
            <button
              key={id}
              className={`pg-cat__filter ${filter === id ? "is-active" : ""}`}
              onClick={() => setFilter(id)}
              data-hover
            >
              {t}
            </button>
          ))}
        </div>
        <div className="mono pg-cat__sort">↳ сначала новые</div>
      </div>

      <section className="pg-cat__grid">
        {[...PRODUCTS, ...PRODUCTS].map((p, i) => (
          <Reveal key={i} kind="up" delay={(i % 3) * 80}>
            <article className="ed-card" data-hover>
              <div className="ed-card__media">
                <img src={p.img} alt={p.name} />
                <span className="ed-card__num mono">N°{String(i + 1).padStart(2, "0")}</span>
              </div>
              <div className="ed-card__meta">
                <div className="ed-card__row">
                  <h4 className="serif ed-card__t">{p.name}</h4>
                  <span className="ed-card__price">{fmtPrice(p.price)}</span>
                </div>
                <div className="ed-card__sub">{p.composition}</div>
              </div>
            </article>
          </Reveal>
        ))}
      </section>

      <Footer />
    </div>
  );
}

Object.assign(window, { PageProduct, PageCheckout, PageAbout, PageContacts, PageShipping, PageCatalog });
