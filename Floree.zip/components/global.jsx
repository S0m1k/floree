/* global.jsx — shared chrome and effects across all Floree concepts */

const { useState, useEffect, useRef, useLayoutEffect } = React;

/* ---------- IMAGES ---------- */
/* Curated, content-appropriate Unsplash photos: white/cream backdrops, dusty rose tones */
const FLOWER_IMAGES = {
  hero1: "https://images.unsplash.com/photo-1561181286-d3fee7d55364?w=2000&q=80&auto=format&fit=crop",
  hero2: "https://images.unsplash.com/photo-1487530811176-3780de880c2d?w=2000&q=80&auto=format&fit=crop",
  hero3: "https://images.unsplash.com/photo-1455659817273-f96807779a8a?w=2000&q=80&auto=format&fit=crop",
  hero4: "https://images.unsplash.com/photo-1508610048659-a06b669e3321?w=2000&q=80&auto=format&fit=crop",

  rose:    "https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=1400&q=80&auto=format&fit=crop",
  peony:   "https://images.unsplash.com/photo-1591886960571-74d43a9d4166?w=1400&q=80&auto=format&fit=crop",
  ranun:   "https://images.unsplash.com/photo-1487070183336-b863922373d4?w=1400&q=80&auto=format&fit=crop",
  tulip:   "https://images.unsplash.com/photo-1520763185298-1b434c919102?w=1400&q=80&auto=format&fit=crop",
  white:   "https://images.unsplash.com/photo-1523694576729-1d925f0db8b3?w=1400&q=80&auto=format&fit=crop",
  pink:    "https://images.unsplash.com/photo-1597848212624-a19eb35e2651?w=1400&q=80&auto=format&fit=crop",
  blush:   "https://images.unsplash.com/photo-1502209524164-acea936639a2?w=1400&q=80&auto=format&fit=crop",
  field:   "https://images.unsplash.com/photo-1469259943454-aa100abba749?w=1400&q=80&auto=format&fit=crop",
  studio:  "https://images.unsplash.com/photo-1487700160041-babef9c3cb55?w=1400&q=80&auto=format&fit=crop",
  hand:    "https://images.unsplash.com/photo-1506784983877-45594efa4cbe?w=1400&q=80&auto=format&fit=crop",
  vase:    "https://images.unsplash.com/photo-1490750967868-88aa4486c946?w=1400&q=80&auto=format&fit=crop",
  wedding: "https://images.unsplash.com/photo-1519741497674-611481863552?w=1400&q=80&auto=format&fit=crop",
  florist: "https://images.unsplash.com/photo-1456428199391-a3b1cb5e93ab?w=1400&q=80&auto=format&fit=crop",
};

/* ---------- PRODUCTS ---------- */
const PRODUCTS = [
  { id: "noir",     name: "Noir",      price: 8400,  size: "M", img: FLOWER_IMAGES.peony,  composition: "Пионы, лизиантус, гортензия, эвкалипт" },
  { id: "blanc",    name: "Blanc",     price: 6200,  size: "S", img: FLOWER_IMAGES.white,  composition: "Белые розы David Austin, фрезия, лизиантус" },
  { id: "rosee",    name: "Rosée",     price: 9800,  size: "L", img: FLOWER_IMAGES.blush,  composition: "Пионовидные розы, ранункулюсы, гортензия" },
  { id: "matin",    name: "Matin",     price: 5400,  size: "S", img: FLOWER_IMAGES.tulip,  composition: "Французские тюльпаны, мускари, эвкалипт" },
  { id: "soir",     name: "Soir",      price: 12400, size: "L", img: FLOWER_IMAGES.rose,   composition: "Тёмно-бордовые розы, орхидея, дымка" },
  { id: "verger",   name: "Verger",    price: 7600,  size: "M", img: FLOWER_IMAGES.ranun,  composition: "Ранункулюсы, ветви яблони, фрезия" },
  { id: "secret",   name: "Secret",    price: 11200, size: "L", img: FLOWER_IMAGES.pink,   composition: "Пионы Sarah Bernhardt, гортензия, скабиоза" },
  { id: "atelier",  name: "Atelier",   price: 15400, size: "XL", img: FLOWER_IMAGES.field, composition: "Авторская композиция флориста (сезон)" },
  { id: "lumiere",  name: "Lumière",   price: 6800,  size: "M", img: FLOWER_IMAGES.vase,   composition: "Эустома, гортензия, кустовая роза" },
];

const fmtPrice = (n) => new Intl.NumberFormat("ru-RU").format(n) + " ₽";

/* ---------- CUSTOM CURSOR (ring follower) ---------- */
function CustomCursor({ scope }) {
  const ringRef = useRef(null);
  const dotRef = useRef(null);
  const stateRef = useRef({ x: 0, y: 0, tx: 0, ty: 0, big: false, raf: 0 });

  useEffect(() => {
    const root = scope?.current || document.body;
    const onMove = (e) => {
      const r = root.getBoundingClientRect();
      stateRef.current.tx = e.clientX - r.left;
      stateRef.current.ty = e.clientY - r.top;
      if (dotRef.current) {
        dotRef.current.style.transform = `translate3d(${stateRef.current.tx}px, ${stateRef.current.ty}px, 0)`;
      }
    };
    const tick = () => {
      const s = stateRef.current;
      s.x += (s.tx - s.x) * 0.18;
      s.y += (s.ty - s.y) * 0.18;
      if (ringRef.current) {
        ringRef.current.style.transform = `translate3d(${s.x}px, ${s.y}px, 0) scale(${s.big ? 2.4 : 1})`;
      }
      s.raf = requestAnimationFrame(tick);
    };

    const onEnter = (e) => {
      const t = e.target;
      if (t.closest && t.closest("[data-hover]")) {
        stateRef.current.big = true;
        ringRef.current && ringRef.current.classList.add("is-big");
      }
    };
    const onLeave = (e) => {
      const t = e.target;
      if (t.closest && t.closest("[data-hover]")) {
        stateRef.current.big = false;
        ringRef.current && ringRef.current.classList.remove("is-big");
      }
    };

    root.addEventListener("mousemove", onMove);
    root.addEventListener("mouseover", onEnter);
    root.addEventListener("mouseout", onLeave);
    stateRef.current.raf = requestAnimationFrame(tick);
    return () => {
      root.removeEventListener("mousemove", onMove);
      root.removeEventListener("mouseover", onEnter);
      root.removeEventListener("mouseout", onLeave);
      cancelAnimationFrame(stateRef.current.raf);
    };
  }, []);

  return (
    <div className="fl-cursor" aria-hidden="true">
      <div ref={ringRef} className="fl-cursor__ring"></div>
      <div ref={dotRef} className="fl-cursor__dot"></div>
    </div>
  );
}

/* ---------- REVEAL ON SCROLL ---------- */
function Reveal({ children, as = "div", delay = 0, kind = "up", className = "", ...rest }) {
  const ref = useRef(null);
  const [shown, setShown] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setShown(true)),
      { rootMargin: "0px 0px -10% 0px", threshold: 0.05 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  const Tag = as;
  return (
    <Tag
      ref={ref}
      className={`fl-reveal fl-reveal--${kind} ${shown ? "is-in" : ""} ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
      {...rest}
    >
      {children}
    </Tag>
  );
}

/* image with reveal-mask (curtain wipe) */
function MaskImage({ src, alt = "", aspect = "4/5", className = "", delay = 0 }) {
  const ref = useRef(null);
  const [shown, setShown] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (es) => es.forEach((e) => e.isIntersecting && setShown(true)),
      { rootMargin: "0px 0px -8% 0px", threshold: 0.1 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} className={`fl-mask ${shown ? "is-in" : ""} ${className}`} style={{ aspectRatio: aspect, transitionDelay: `${delay}ms` }}>
      <img src={src} alt={alt} loading="lazy" />
      <span className="fl-mask__veil" style={{ transitionDelay: `${delay}ms` }}></span>
    </div>
  );
}

/* ---------- HEADER ---------- */
function Header({ variant = "light", onCart, cartCount = 0 }) {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => {
      const sc = (document.scrollingElement || document.documentElement).scrollTop;
      setScrolled(sc > 20);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className={`fl-header ${scrolled ? "is-scrolled" : ""} fl-header--${variant}`}>
      <div className="fl-header__inner">
        <nav className="fl-nav fl-nav--left">
          <a href="#catalog" data-hover>Каталог</a>
          <a href="#wedding" data-hover>Свадьба</a>
          <a href="#sub" data-hover>Подписка</a>
        </nav>
        <a href="#" className="fl-logo" data-hover>
          <span className="fl-logo__mark">Floree</span>
          <span className="fl-logo__sub">цветочная студия</span>
        </a>
        <nav className="fl-nav fl-nav--right">
          <a href="#about" data-hover>О студии</a>
          <a href="#contact" data-hover>Контакты</a>
          <button className="fl-cart-btn" onClick={onCart} data-hover>
            Корзина <span className="fl-cart-btn__count">{cartCount}</span>
          </button>
        </nav>
      </div>
    </header>
  );
}

/* ---------- FOOTER ---------- */
function Footer({ tone = "light" }) {
  return (
    <footer className={`fl-footer fl-footer--${tone}`}>
      <div className="fl-footer__hairline"></div>
      <div className="fl-footer__grid">
        <div className="fl-footer__brand">
          <div className="fl-footer__logo">Floree</div>
          <p className="fl-footer__tag">
            Букеты, собранные руками — для тех, кто ценит цветы как способ говорить.
          </p>
        </div>
        <div>
          <div className="eyebrow">Студия</div>
          <ul className="fl-footer__list">
            <li><a href="#" data-hover>Каталог</a></li>
            <li><a href="#" data-hover>Свадебная флористика</a></li>
            <li><a href="#" data-hover>Корпоративным клиентам</a></li>
            <li><a href="#" data-hover>Подписка</a></li>
          </ul>
        </div>
        <div>
          <div className="eyebrow">Информация</div>
          <ul className="fl-footer__list">
            <li><a href="#" data-hover>О студии</a></li>
            <li><a href="#" data-hover>Доставка и оплата</a></li>
            <li><a href="#" data-hover>Контакты</a></li>
            <li><a href="#" data-hover>Уход за букетом</a></li>
          </ul>
        </div>
        <div>
          <div className="eyebrow">Связь</div>
          <ul className="fl-footer__list">
            <li>Полтавский проезд, 2</li>
            <li>Санкт-Петербург</li>
            <li>Ежедневно 09:00 — 21:00</li>
            <li><a href="tel:+79930750577" data-hover>+7 993 075 05 77</a></li>
            <li><a href="#" data-hover>Telegram</a> · <a href="#" data-hover>Instagram</a></li>
          </ul>
        </div>
      </div>
      <div className="fl-footer__bottom">
        <span>© Floree, 2026</span>
        <span className="mono">floree.ru</span>
      </div>
    </footer>
  );
}

/* ---------- TICKER (marquee) ---------- */
function Ticker({ items, speed = 50 }) {
  const list = [...items, ...items];
  return (
    <div className="fl-ticker">
      <div className="fl-ticker__track" style={{ animationDuration: `${speed}s` }}>
        {list.map((it, i) => (
          <span key={i} className="fl-ticker__item">
            <span className="serif">{it}</span>
            <span className="fl-ticker__dot">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { CustomCursor, Reveal, MaskImage, Header, Footer, Ticker, PRODUCTS, FLOWER_IMAGES, fmtPrice });
