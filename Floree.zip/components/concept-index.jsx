/* concept-index.jsx — Concept C: Curated Index (archival, monospace meta, thin lines) */

const { useState: useStateC, useEffect: useEffectC, useRef: useRefC } = React;

function ConceptIndex() {
  const rootRef = useRefC(null);
  const [slide, setSlide] = useStateC(0);
  const [cartOpen, setCartOpen] = useStateC(false);
  const [cart, setCart] = useStateC([]);

  const slides = [
    { img: FLOWER_IMAGES.hero3, idx: "001/024", name: "Verger", season: "spring · 2026" },
    { img: FLOWER_IMAGES.hero1, idx: "002/024", name: "Rosée",  season: "spring · 2026" },
    { img: FLOWER_IMAGES.hero4, idx: "003/024", name: "Soir",   season: "spring · 2026" },
    { img: FLOWER_IMAGES.hero2, idx: "004/024", name: "Matin",  season: "spring · 2026" },
  ];

  useEffectC(() => {
    const id = setInterval(() => setSlide((s) => (s + 1) % slides.length), 5000);
    return () => clearInterval(id);
  }, []);

  const addToCart = (p) => { setCart((c) => [...c, p]); setCartOpen(true); };

  return (
    <div ref={rootRef} className="ix-root">
      <CustomCursor scope={rootRef} />
      <Header onCart={() => setCartOpen(true)} cartCount={cart.length} />

      {/* HERO — index strip on top, image fills */}
      <section className="ix-hero">
        <div className="ix-hero__top">
          <div className="ix-hero__top-row">
            <span className="mono">FLOREE — FLOWER STUDIO</span>
            <span className="mono">SAINT&nbsp;PETERSBURG / RU</span>
            <span className="mono">EST&nbsp;2018</span>
            <span className="mono">№ {slides[slide].idx}</span>
          </div>
        </div>

        <div className="ix-hero__media">
          {slides.map((s, i) => (
            <div key={i} className={`ix-hero__slide ${i === slide ? "is-active" : ""}`}>
              <img src={s.img} alt={s.name} />
            </div>
          ))}
        </div>

        <div className="ix-hero__bottom">
          <div>
            <div className="eyebrow">Index 026</div>
            <h1 className="serif ix-hero__title">
              The <em>quiet</em> florist's<br/>
              archive of bouquets.
            </h1>
          </div>
          <div className="ix-hero__bottom-meta">
            <div className="ix-hero__pair">
              <span className="mono">title</span>
              <span className="serif"><em>{slides[slide].name}</em></span>
            </div>
            <div className="ix-hero__pair">
              <span className="mono">season</span>
              <span className="mono">{slides[slide].season}</span>
            </div>
            <button className="btn btn--filled" data-hover>Открыть архив</button>
          </div>
        </div>

        {/* dots */}
        <div className="ix-hero__pager">
          {slides.map((_, i) => (
            <button
              key={i}
              className={`ix-hero__pager-dot ${i === slide ? "is-active" : ""}`}
              onClick={() => setSlide(i)}
              data-hover
            />
          ))}
        </div>
      </section>

      {/* INDEX BAR — categories as table */}
      <section className="ix-bar">
        <div className="ix-bar__row mono">
          <span className="ix-bar__label">CATEGORIES</span>
          <a href="#" data-hover>01 · сезон</a>
          <a href="#" data-hover>02 · ежедневные</a>
          <a href="#" data-hover>03 · свадьба</a>
          <a href="#" data-hover>04 · подписка</a>
          <a href="#" data-hover>05 · корпоративные</a>
          <a href="#" data-hover>06 · композиции</a>
        </div>
      </section>

      {/* MANIFESTO */}
      <section className="ix-manifesto">
        <div className="ix-manifesto__col">
          <Reveal kind="up">
            <span className="mono ix-manifesto__num">— 01</span>
          </Reveal>
        </div>
        <div className="ix-manifesto__main">
          <Reveal kind="up" delay={100}>
            <h2 className="serif ix-manifesto__t">
              Floree — это не магазин цветов.<br/>
              Это <em>каталог</em> того, что мы&nbsp;нашли красивым.
            </h2>
          </Reveal>
          <Reveal kind="up" delay={200}>
            <p className="ix-manifesto__p">
              Каждое утро мы&nbsp;едем на&nbsp;завоз, выбираем то, что нравится нам самим,
              и&nbsp;собираем из&nbsp;этого ограниченную серию букетов. На&nbsp;следующий день — другую.
            </p>
          </Reveal>
        </div>
      </section>

      {/* PRODUCT INDEX — table-like grid */}
      <section className="ix-catalog" id="catalog">
        <div className="ix-catalog__head">
          <Reveal kind="up">
            <div className="ix-catalog__head-row">
              <span className="mono">— 02 / каталог</span>
              <span className="mono">всего: 24 / показано: 9</span>
            </div>
            <h2 className="serif ix-catalog__title">Все букеты <em>в наличии</em></h2>
          </Reveal>
        </div>

        <div className="ix-catalog__filters mono">
          <span className="ix-catalog__filter is-active">все</span>
          <span className="ix-catalog__filter">до 6&nbsp;000 ₽</span>
          <span className="ix-catalog__filter">6 — 10&nbsp;000 ₽</span>
          <span className="ix-catalog__filter">от 10&nbsp;000 ₽</span>
          <span className="ix-catalog__filter">премиум</span>
          <span className="ix-catalog__sort">↳ по цене</span>
        </div>

        <div className="ix-catalog__grid">
          {PRODUCTS.map((p, i) => (
            <Reveal key={p.id} kind="up" delay={(i % 3) * 80}>
              <ProductCardIndex product={p} index={i} onAdd={() => addToCart(p)} />
            </Reveal>
          ))}
        </div>
      </section>

      {/* STUDIO BLOCK — table specs */}
      <section className="ix-studio" id="about">
        <Reveal kind="up">
          <span className="mono ix-manifesto__num">— 03 / studio</span>
        </Reveal>
        <div className="ix-studio__grid">
          <div className="ix-studio__media">
            <MaskImage src={FLOWER_IMAGES.florist} alt="Студия" aspect="3/4" />
          </div>
          <div className="ix-studio__copy">
            <Reveal kind="up">
              <h3 className="serif ix-studio__t">
                Четыре флориста,<br/>одна <em>мастерская</em>.
              </h3>
            </Reveal>
            <Reveal kind="up" delay={120}>
              <p>
                Мы&nbsp;любим работать с&nbsp;европейской школой композиции — длинные стебли,
                воздух между цветами, приглушённые тоновые сочетания. Каждый букет —
                ручная сборка одного флориста, без&nbsp;конвейера и&nbsp;готовых шаблонов.
              </p>
            </Reveal>
            <dl className="ix-studio__specs mono">
              {[
                ["адрес",      "Полтавский проезд, 2"],
                ["метро",      "Площадь Восстания · 4 мин"],
                ["часы",       "ежедневно 09:00 — 21:00"],
                ["флористы",   "Анна, Дарья, Юля, Михаил"],
                ["с 2018 года", "более 12 000 букетов"],
              ].map(([k, v]) => (
                <Reveal as="div" key={k} kind="up" className="ix-studio__row">
                  <dt>{k}</dt>
                  <dd>{v}</dd>
                </Reveal>
              ))}
            </dl>
          </div>
        </div>
      </section>

      {/* ARCHIVE STRIP — small thumbnails marching */}
      <section className="ix-archive">
        <Reveal kind="up">
          <div className="ix-archive__head mono">
            <span>— 04 / archive</span>
            <span>2018 — 2026</span>
          </div>
        </Reveal>
        <div className="ix-archive__strip">
          {Array.from({ length: 14 }).map((_, i) => {
            const imgs = Object.values(FLOWER_IMAGES);
            return (
              <div key={i} className="ix-archive__cell" data-hover>
                <img src={imgs[i % imgs.length]} alt={`Archive ${i}`} loading="lazy" />
                <div className="mono ix-archive__cap">№ {String(i + 1).padStart(3, "0")}</div>
              </div>
            );
          })}
        </div>
      </section>

      {/* CTA */}
      <section className="ix-cta">
        <Reveal kind="up">
          <div className="ix-cta__line mono">— 05 / contact</div>
        </Reveal>
        <Reveal kind="up" delay={120}>
          <h3 className="serif ix-cta__t">
            Хотите собрать что-то<br/>
            <em>не из каталога?</em>
          </h3>
        </Reveal>
        <div className="ix-cta__actions">
          <a href="tel:+79930750577" className="ix-cta__phone serif">+7&nbsp;993&nbsp;075&nbsp;05&nbsp;77</a>
          <div className="ix-cta__lks">
            <a href="#" className="btn" data-hover>Telegram</a>
            <a href="#" className="btn" data-hover>WhatsApp</a>
            <a href="#" className="btn btn--filled" data-hover>Написать в студию</a>
          </div>
        </div>
      </section>

      <Footer />

      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} items={cart} setItems={setCart} />
    </div>
  );
}

function ProductCardIndex({ product, index, onAdd }) {
  return (
    <article className="ix-card" data-hover>
      <div className="ix-card__head mono">
        <span>№ {String(index + 1).padStart(3, "0")}</span>
        <span>{product.size}</span>
      </div>
      <div className="ix-card__media">
        <img src={product.img} alt={product.name} loading="lazy" />
        <button className="ix-card__add" onClick={onAdd} data-hover>+ в корзину</button>
      </div>
      <div className="ix-card__foot">
        <div>
          <h4 className="serif ix-card__t">{product.name}</h4>
          <div className="ix-card__sub">{product.composition}</div>
        </div>
        <div className="ix-card__price mono">{fmtPrice(product.price)}</div>
      </div>
    </article>
  );
}

Object.assign(window, { ConceptIndex });
