/* concept-editorial.jsx — Concept A: Editorial Gallery */

const { useState: useStateA, useEffect: useEffectA, useRef: useRefA } = React;

function ConceptEditorial() {
  const rootRef = useRefA(null);
  const [slide, setSlide] = useStateA(0);
  const [cartOpen, setCartOpen] = useStateA(false);
  const [cart, setCart] = useStateA([]);

  const slides = [
    { img: FLOWER_IMAGES.hero1, name: "N° 01 — Rosée",  caption: "Пионовидные розы и ранункулюс" },
    { img: FLOWER_IMAGES.hero2, name: "N° 02 — Matin",  caption: "Французские тюльпаны на длинных стеблях" },
    { img: FLOWER_IMAGES.hero3, name: "N° 03 — Verger", caption: "Ветви яблони и кустовая роза" },
    { img: FLOWER_IMAGES.hero4, name: "N° 04 — Soir",   caption: "Тёмная композиция на вечер" },
  ];

  useEffectA(() => {
    const id = setInterval(() => setSlide((s) => (s + 1) % slides.length), 5500);
    return () => clearInterval(id);
  }, []);

  const addToCart = (p) => { setCart((c) => [...c, p]); setCartOpen(true); };

  return (
    <div ref={rootRef} className="ed-root">
      <CustomCursor scope={rootRef} />
      <Header onCart={() => setCartOpen(true)} cartCount={cart.length} />

      {/* HERO — slide carousel with editorial caption */}
      <section className="ed-hero">
        <div className="ed-hero__stage">
          {slides.map((s, i) => (
            <div key={i} className={`ed-hero__slide ${i === slide ? "is-active" : ""}`}>
              <img src={s.img} alt={s.name} />
            </div>
          ))}
          <div className="ed-hero__veil" />
        </div>

        <div className="ed-hero__copy">
          <div className="eyebrow">Цветочная студия · Санкт-Петербург</div>
          <h1 className="ed-hero__title serif">
            Букеты,<br/>
            <em>собранные руками</em><br/>
            и сердцем.
          </h1>
          <div className="ed-hero__meta">
            <div className="ed-hero__counter mono">
              {String(slide + 1).padStart(2, "0")} <span>/</span> {String(slides.length).padStart(2, "0")}
            </div>
            <div className="ed-hero__caption">
              <div className="serif" style={{ fontSize: 22, fontStyle: "italic" }}>{slides[slide].name}</div>
              <div style={{ color: "var(--ink-2)", marginTop: 4 }}>{slides[slide].caption}</div>
            </div>
            <button className="btn btn--filled" data-hover>
              Заказать букет
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M1 7H13M13 7L8 2M13 7L8 12" stroke="currentColor"/></svg>
            </button>
          </div>

          <div className="ed-hero__dots">
            {slides.map((_, i) => (
              <button
                key={i}
                className={`ed-hero__dot ${i === slide ? "is-active" : ""}`}
                onClick={() => setSlide(i)}
                data-hover
                aria-label={`Слайд ${i + 1}`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* INTRO — editorial paragraph */}
      <section className="ed-intro">
        <Reveal kind="up">
          <div className="eyebrow" style={{ marginBottom: 24 }}>— Манифест</div>
        </Reveal>
        <Reveal kind="up" delay={120}>
          <p className="ed-intro__lede serif">
            Мы — небольшая студия в&nbsp;центре Петербурга. Каждое&nbsp;утро встречаем новый завоз
            из&nbsp;Голландии, выбираем самые тонкие, самые живые цветы — и&nbsp;собираем
            из&nbsp;них то, что хочется держать в&nbsp;руках.
          </p>
        </Reveal>
      </section>

      {/* TICKER */}
      <Ticker items={["Цветы дня", "Свадебная флористика", "Подписка", "Корпоративные заказы", "Доставка по СПб"]} speed={45} />

      {/* CATALOG TEASER — 4 featured */}
      <section className="ed-catalog" id="catalog">
        <div className="ed-catalog__head">
          <Reveal kind="up">
            <div className="eyebrow">— Каталог N° 01</div>
            <h2 className="serif ed-catalog__title">
              Букеты <em>сезона</em>
            </h2>
          </Reveal>
          <Reveal kind="up" delay={150}>
            <a href="#" className="ed-catalog__all" data-hover>
              Смотреть все 24
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M1 7H13M13 7L8 2M13 7L8 12" stroke="currentColor"/></svg>
            </a>
          </Reveal>
        </div>

        <div className="ed-catalog__grid">
          {PRODUCTS.slice(0, 4).map((p, i) => (
            <Reveal key={p.id} kind="up" delay={i * 100} className="ed-card-wrap">
              <ProductCardEditorial product={p} index={i} onAdd={() => addToCart(p)} />
            </Reveal>
          ))}
        </div>
      </section>

      {/* EDITORIAL SPLIT — story + image */}
      <section className="ed-story">
        <div className="ed-story__media">
          <MaskImage src={FLOWER_IMAGES.studio} alt="Студия Floree" aspect="4/5" />
          <div className="ed-story__caption mono">
            ↳ Полтавский проезд, 2 · мастерская
          </div>
        </div>
        <div className="ed-story__copy">
          <Reveal kind="up">
            <div className="eyebrow">— О студии</div>
          </Reveal>
          <Reveal kind="up" delay={120}>
            <h3 className="serif ed-story__title">
              Тишина мастерской<br/>и&nbsp;звук <em>секатора</em>.
            </h3>
          </Reveal>
          <Reveal kind="up" delay={220}>
            <p className="ed-story__text">
              Floree — это четыре флориста, одна мастерская и&nbsp;тысячи стеблей,
              проходящих через наши руки за&nbsp;год. Мы&nbsp;работаем с&nbsp;цветами так,
              как нам бы&nbsp;самим хотелось их&nbsp;получить — без&nbsp;лишнего, без&nbsp;надрыва,
              с&nbsp;вниманием к&nbsp;каждому стеблю.
            </p>
          </Reveal>
          <Reveal kind="up" delay={320}>
            <a href="#" className="btn" data-hover style={{ marginTop: 32 }}>
              Прочитать историю
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M1 7H13M13 7L8 2M13 7L8 12" stroke="currentColor"/></svg>
            </a>
          </Reveal>
        </div>
      </section>

      {/* CATEGORIES — 3 wide tiles */}
      <section className="ed-cats">
        <Reveal kind="up">
          <div className="eyebrow" style={{ textAlign: "center" }}>— Что мы делаем</div>
          <h2 className="serif ed-cats__title">Три направления студии</h2>
        </Reveal>
        <div className="ed-cats__row">
          {[
            { t: "Авторские букеты", sub: "Каждый день — свежие композиции от&nbsp;флористов студии", img: FLOWER_IMAGES.hand, n: "01" },
            { t: "Свадебная флористика", sub: "От&nbsp;букета невесты до&nbsp;арки и&nbsp;оформления зала", img: FLOWER_IMAGES.wedding, n: "02" },
            { t: "Подписка на цветы", sub: "Свежие букеты домой каждую неделю или раз в&nbsp;две", img: FLOWER_IMAGES.vase, n: "03" },
          ].map((c, i) => (
            <Reveal key={i} kind="up" delay={i * 120} className="ed-cat">
              <div className="ed-cat__media" data-hover>
                <MaskImage src={c.img} alt={c.t} aspect="3/4" delay={i * 100} />
              </div>
              <div className="ed-cat__meta">
                <span className="mono ed-cat__n">N°{c.n}</span>
                <h4 className="serif ed-cat__t" dangerouslySetInnerHTML={{ __html: c.t }} />
                <p className="ed-cat__sub" dangerouslySetInnerHTML={{ __html: c.sub }} />
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* QUOTE */}
      <section className="ed-quote">
        <Reveal kind="fade">
          <blockquote className="serif ed-quote__text">
            «Цветок — это <em>письмо</em>, которое не нужно читать.<br/>
            Достаточно держать в&nbsp;руках.»
          </blockquote>
        </Reveal>
        <Reveal kind="up" delay={300}>
          <div className="eyebrow">— Анна, главный флорист</div>
        </Reveal>
      </section>

      {/* JOURNAL — blog teaser */}
      <section className="ed-journal">
        <div className="ed-catalog__head">
          <Reveal kind="up">
            <div className="eyebrow">— Журнал</div>
            <h2 className="serif ed-catalog__title">Заметки <em>флориста</em></h2>
          </Reveal>
        </div>
        <div className="ed-journal__grid">
          {[
            { t: "Как сохранить пионы свежими дольше недели", date: "12.04.2026", img: FLOWER_IMAGES.peony, tag: "Уход" },
            { t: "Семь оттенков белого: язык свадебных букетов", date: "28.03.2026", img: FLOWER_IMAGES.white, tag: "Свадьба" },
            { t: "Голландский аукцион глазами петербургского флориста", date: "09.03.2026", img: FLOWER_IMAGES.field, tag: "Студия" },
          ].map((a, i) => (
            <Reveal key={i} kind="up" delay={i * 120}>
              <article className="ed-article" data-hover>
                <MaskImage src={a.img} alt={a.t} aspect="4/3" delay={i * 80} />
                <div className="ed-article__meta">
                  <span className="mono">{a.date}</span>
                  <span className="mono">· {a.tag}</span>
                </div>
                <h4 className="serif ed-article__t">{a.t}</h4>
              </article>
            </Reveal>
          ))}
        </div>
      </section>

      {/* CTA — newsletter */}
      <section className="ed-cta">
        <Reveal kind="up">
          <div className="ed-cta__inner">
            <h3 className="serif ed-cta__t">
              Получайте по&nbsp;утрам<br/>
              <em>письмо из&nbsp;студии</em>.
            </h3>
            <p className="ed-cta__p">
              Новые букеты, заметки и&nbsp;скрытые скидки — раз в&nbsp;две недели.
            </p>
            <form className="ed-cta__form" onSubmit={(e) => e.preventDefault()}>
              <input type="email" placeholder="ваш e-mail" />
              <button className="btn btn--filled" data-hover>Подписаться</button>
            </form>
          </div>
        </Reveal>
      </section>

      <Footer />

      {/* CART DRAWER */}
      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} items={cart} setItems={setCart} />
    </div>
  );
}

/* ---------- Editorial product card ---------- */
function ProductCardEditorial({ product, index, onAdd }) {
  return (
    <article className="ed-card" data-hover>
      <div className="ed-card__media">
        <img src={product.img} alt={product.name} loading="lazy" />
        <div className="ed-card__overlay">
          <button className="btn btn--filled" onClick={onAdd} data-hover>В корзину · {fmtPrice(product.price)}</button>
        </div>
        <span className="ed-card__num mono">N°{String(index + 1).padStart(2, "0")}</span>
      </div>
      <div className="ed-card__meta">
        <div className="ed-card__row">
          <h4 className="serif ed-card__t">{product.name}</h4>
          <span className="ed-card__price">{fmtPrice(product.price)}</span>
        </div>
        <div className="ed-card__sub">{product.composition}</div>
      </div>
    </article>
  );
}

/* ---------- Cart drawer ---------- */
function CartDrawer({ open, onClose, items, setItems }) {
  const total = items.reduce((s, p) => s + p.price, 0);
  const remove = (i) => setItems((arr) => arr.filter((_, idx) => idx !== i));

  return (
    <>
      <div className={`fl-cart-scrim ${open ? "is-open" : ""}`} onClick={onClose} />
      <aside className={`fl-cart ${open ? "is-open" : ""}`} aria-hidden={!open}>
        <header className="fl-cart__head">
          <div>
            <div className="eyebrow">Корзина</div>
            <div className="serif" style={{ fontSize: 28, fontStyle: "italic", marginTop: 4 }}>
              {items.length} {items.length === 1 ? "букет" : items.length > 1 && items.length < 5 ? "букета" : "букетов"}
            </div>
          </div>
          <button className="fl-cart__close" onClick={onClose} data-hover>×</button>
        </header>
        <div className="fl-cart__list">
          {items.length === 0 && (
            <div className="fl-cart__empty">
              <p className="serif" style={{ fontStyle: "italic", fontSize: 22 }}>Пока пусто.</p>
              <p style={{ color: "var(--ink-2)" }}>Загляните в каталог — там сейчас 24 букета.</p>
            </div>
          )}
          {items.map((p, i) => (
            <div key={i} className="fl-cart__item">
              <img src={p.img} alt={p.name} />
              <div className="fl-cart__item-meta">
                <div className="serif" style={{ fontSize: 20 }}>{p.name}</div>
                <div style={{ color: "var(--ink-3)", fontSize: 13 }}>{p.composition}</div>
                <div style={{ marginTop: 8, fontFamily: "var(--mono)", fontSize: 13 }}>{fmtPrice(p.price)}</div>
              </div>
              <button className="fl-cart__rm" onClick={() => remove(i)} data-hover>удалить</button>
            </div>
          ))}
        </div>
        <footer className="fl-cart__foot">
          <div className="fl-cart__total">
            <span className="eyebrow">Итого</span>
            <span className="serif" style={{ fontSize: 28 }}>{fmtPrice(total)}</span>
          </div>
          <button className="btn btn--filled fl-cart__checkout" data-hover>
            Оформить заказ
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M1 7H13M13 7L8 2M13 7L8 12" stroke="currentColor"/></svg>
          </button>
        </footer>
      </aside>
    </>
  );
}

Object.assign(window, { ConceptEditorial, ProductCardEditorial, CartDrawer });
